upload the folder CookieMOD to your forum root. Navigate to it using your browser.  
ie..www.yoursite.com/forum/cookieMOD/cookie.php
Unless you are familiar with setting cookies, just choose save. your done. 